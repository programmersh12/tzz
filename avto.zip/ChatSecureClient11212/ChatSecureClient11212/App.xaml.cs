﻿using System.Windows;

namespace ChatSecureClient11212
{
    public partial class App : Application
    {
    }
}
